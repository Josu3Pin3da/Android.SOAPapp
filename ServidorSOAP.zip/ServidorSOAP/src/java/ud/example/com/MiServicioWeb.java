/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ud.example.com;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author JIPINEDAZ
 */
@WebService(serviceName = "MiServicioWeb")
public class MiServicioWeb {
    private double Euro;
    public MiServicioWeb(){
        Euro = 4237.77;
    }
    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
   /**
    * Web service operation
    */
    @WebMethod(operationName = "getEuro")
    public double getEuro(){
    return Euro;
    }
       /**
    * Web service operation
    */
@WebMethod(operationName = "Peso2Euro")
public double Peso2Euro(@WebParam(name = "valor")String valor1){
    return Double.parseDouble(valor1)/Euro;
}
/**
 * Web service operation
 */
@WebMethod(operationName = "Euro2Peso")
public double Euro2Peso(@WebParam(name = "valor")String valor1){
    return Double.parseDouble(valor1)*Euro;
}
}